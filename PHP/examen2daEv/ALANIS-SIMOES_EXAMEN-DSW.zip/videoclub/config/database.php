<?php

    define("SERVERNAME", "localhost");
    define("DATABASE", "videoclub");
    define("USER", "root");
    define("PASS", "");

?>