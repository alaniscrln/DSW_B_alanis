<?php
    define("SERVERNAME", "localhost");
    define("DATABASE", "agenda");
    define("USER", "root");
    define("PASS", "");
?>